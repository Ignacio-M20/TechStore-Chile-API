package cl.techstore.api.service;

import cl.techstore.api.dto.ProductoDTO;
import cl.techstore.api.model.Producto;
import cl.techstore.api.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Servicio que contiene la lógica de negocio para la gestión de Productos.
 * Actúa como intermediario entre el controlador y el repositorio.
 */
@Service
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    /**
     * Retorna todos los productos activos en el catálogo.
     *
     * @return lista de productos con activo = true
     */
    public List<Producto> listarTodos() {
        return productoRepository.findByActivoTrue();
    }

    /**
     * Crea un nuevo producto en el catálogo.
     *
     * @param dto datos del producto a crear
     * @return el producto persistido con su ID asignado
     */
    public Producto crear(ProductoDTO dto) {
        Producto producto = new Producto();
        producto.setNombre(dto.getNombre());
        producto.setDescripcion(dto.getDescripcion());
        producto.setPrecio(dto.getPrecio());
        producto.setStock(dto.getStock());
        producto.setCategoria(dto.getCategoria());
        // El campo activo es true por defecto
        producto.setActivo(dto.getActivo() != null ? dto.getActivo() : true);
        return productoRepository.save(producto);
    }

    /**
     * Modifica un producto existente con los nuevos datos proporcionados.
     *
     * @param id  ID del producto a modificar
     * @param dto nuevos datos del producto
     * @return el producto actualizado
     * @throws RuntimeException si el producto no existe
     */
    public Producto modificar(Long id, ProductoDTO dto) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + id));

        producto.setNombre(dto.getNombre());
        producto.setDescripcion(dto.getDescripcion());
        producto.setPrecio(dto.getPrecio());
        producto.setStock(dto.getStock());
        producto.setCategoria(dto.getCategoria());
        if (dto.getActivo() != null) {
            producto.setActivo(dto.getActivo());
        }

        return productoRepository.save(producto);
    }

    /**
     * Realiza el borrado lógico de un producto (activo = false).
     * El registro permanece en la base de datos pero no aparece en los listados.
     *
     * @param id ID del producto a eliminar lógicamente
     * @throws RuntimeException si el producto no existe
     */
    public void eliminar(Long id) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + id));
        producto.setActivo(false);
        productoRepository.save(producto);
    }
}
